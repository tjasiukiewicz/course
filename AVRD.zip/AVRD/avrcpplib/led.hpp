#ifndef LED_HPP_
#define LED_HPP_

#include <ports.hpp>
#include <stdint.h>

namespace avrcpplib
{

enum class LedMode
{
	SINK_LED, SOURCE_LED
};

template<typename LedPort, uint8_t BitNumber, LedMode Mode = LedMode::SINK_LED>
class Led
{
public:
	static void init();
	static void on();
	static void off();
	static void toggle();
};

template<typename LedPort, uint8_t BitNumber, LedMode Mode>
void Led<LedPort, BitNumber, Mode>::init()
{
	BitInRWPort<typename LedPort::mode_t, BitNumber>::set();
	Mode == LedMode::SOURCE_LED ?
			BitInRWPort<typename LedPort::output_t, BitNumber>::clear() :
			BitInRWPort<typename LedPort::output_t, BitNumber>::set();
}

template<typename LedPort, uint8_t BitNumber, LedMode Mode>
void Led<LedPort, BitNumber, Mode>::on()
{
	Mode == LedMode::SOURCE_LED ?
			BitInRWPort<typename LedPort::output_t, BitNumber>::clear() :
			BitInRWPort<typename LedPort::output_t, BitNumber>::set();
}

template<typename LedPort, uint8_t BitNumber, LedMode Mode>
void Led<LedPort, BitNumber, Mode>::off()
{
	Mode == LedMode::SOURCE_LED ?
			BitInRWPort<typename LedPort::output_t, BitNumber>::set() :
			BitInRWPort<typename LedPort::output_t, BitNumber>::clear();
}

template<typename LedPort, uint8_t BitNumber, LedMode Mode>
void Led<LedPort, BitNumber, Mode>::toggle()
{
	BitInRWPort<typename LedPort::output_t, BitNumber>::toggle();
}

}  // namespace avrcpplib

#endif /* LED_HPP_ */

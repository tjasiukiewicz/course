#ifndef UTIL_HPP_
#define UTIL_HPP_

#include <stdint.h>

namespace avrcpplib
{

template<typename ValueType>
constexpr ValueType countLeastZero(ValueType) = delete;

// Count least significant zero bits, uint8_t version.
template<>
constexpr uint8_t countLeastZero(uint8_t value)
{
	if (value & 0x0F)
	{
		if (value & 0x03)
		{
			return value & 0x01 ? 0 : 1;
		}
		else if (value & 0x04)
		{
			return 2;
		}
		else
		{
			return 3;
		}
	}
	else if (value & 0x30)
	{
		return value & 0x10 ? 4 : 5;
	}
	else if (value & 0x40)
	{
		return 6;
	}
	else if (value)
	{
		return 7;
	}
	return 8;
}

// Count least significant zero bits, uint16_t version.
template<>
constexpr uint16_t countLeastZero(uint16_t value)
{
	return countLeastZero(static_cast<uint8_t>(value >> 8))
			+ countLeastZero(static_cast<uint8_t>(value & 0xFF));
}

// Count least significant zero bits, uint32_t version.
template<>
constexpr auto countLeastZero(uint32_t value) -> decltype(value)
{
	return countLeastZero(static_cast<uint16_t>(value >> 16))
			+ countLeastZero(static_cast<uint16_t>(value & 0x0000FFFF));
}

// Count enabled bits, generic version
template<typename ValueType>
constexpr uint8_t countEnabledBits(ValueType value) = delete;

// Couunt enabled bits, uint8_t version.
template<>
constexpr uint8_t countEnabledBits(uint8_t value)
{
	value = (value & 0x55) + ((value >> 1) & 0x55);
	value = (value & 0x33) + ((value >> 2) & 0x33);
	value = (value & 0x0F) + ((value >> 4) & 0x0F);
	return value;
}

// Couunt enabled bits, uint16_t version.
template<>
constexpr uint8_t countEnabledBits(uint16_t value)
{
	value = (value & 0x5555) + ((value >> 1) & 0x5555);
	value = (value & 0x3333) + ((value >> 2) & 0x3333);
	value = (value & 0x0F0F) + ((value >> 4) & 0x0F0F);
	value = (value & 0x00FF) + ((value >> 8) & 0x00FF);
	return static_cast<uint8_t>(value);
}

// Couunt enabled bits, uint32_t version.
template<>
constexpr uint8_t countEnabledBits(uint32_t value)
{
	value = (value & 0x55555555) + ((value >> 1) & 0x55555555);
	value = (value & 0x33333333) + ((value >> 2) & 0x33333333);
	value = (value & 0x0F0F0F0F) + ((value >> 4) & 0x0F0F0F0F);
	value = (value & 0x00FF00FF) + ((value >> 8) & 0x00FF00FF);
	value = (value & 0x0000FFFF) + ((value >> 16) & 0x000FFFF);
	return static_cast<uint8_t>(value);
}

}  // namespace avrcpplib

#endif /* UTIL_HPP_ */

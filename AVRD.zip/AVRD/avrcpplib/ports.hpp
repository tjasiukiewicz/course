#ifndef PORTS_HPP_
#define PORTS_HPP_

#include <avr/io.h>
#include <stdbool.h>
#include <stdint.h>

namespace avrcpplib
{

template<typename ValueType, uint8_t DataBits = 8, uint8_t BufferSize = 0>
struct IOTraits
{
	using value_type = ValueType;
	constexpr static uint8_t count_bits = DataBits;
	constexpr static uint8_t buffer_size = BufferSize;
};

#define IORWPort8(port_name) struct ReadWritePort8##port_name: 	\
		public IOTraits<uint8_t> {        						\
	static volatile uint8_t * ptr() { return &port_name; }   		\
	void operator=(const uint8_t& value) { *ptr() = value; } 		\
}

#define IOROPort8(port_name) struct ReadOnlyPort8##port_name: 	\
		public IOTraits<uint8_t> {								\
	static const volatile uint8_t * ptr() { return &port_name; }	\
}

#define IORWPort16(port_name) struct ReadWritePort16##port_name:	\
		public IOTraits<uint8_t> {        						\
	static volatile uint16_t * ptr() { return &port_name; }   	\
	void operator=(const uint16_t& value) { *ptr() = value; } 	\
}

#define IOROPort16(port_name) struct ReadOnlyPort16##port_name:	\
		public IOTraits<uint8_t> {								\
	static const volatile uint16_t * ptr() { return &port_name; }	\
}

// RW
template<class IOPort, uint8_t BitNumber>
struct BitInRWPort: public IOTraits<bool, 1, 0>
{
	static void clear();
	static void set();
	static void toggle();
	static bool valueOf();
};

template<class IOPort, uint8_t BitNumber>
void BitInRWPort<IOPort, BitNumber>::clear()
{
	*IOPort::ptr() &= ~(1 << BitNumber);
}

template<class IOPort, uint8_t BitNumber>
void BitInRWPort<IOPort, BitNumber>::set()
{
	*IOPort::ptr() |= (1 << BitNumber);
}

template<class IOPort, uint8_t BitNumber>
void BitInRWPort<IOPort, BitNumber>::toggle()
{
	*IOPort::ptr() ^= (1 << BitNumber);
}

template<class IOPort, uint8_t BitNumber>
bool BitInRWPort<IOPort, BitNumber>::valueOf()
{
	return *IOPort::ptr() & (1 << BitNumber) ? true : false;
}

// RO
template<class IOPort, uint8_t BitNumber>
struct BitInROPort: public IOTraits<bool, 1, 0>
{
	static bool valueOf();
};

template<class IOPort, uint8_t BitNumber>
bool BitInROPort<IOPort, BitNumber>::valueOf()
{
	return *IOPort::ptr() & (1 << BitNumber) ? true : false;
}

// RW Ports
IORWPort8(DDRA);
IORWPort8(PORTA);
IORWPort8(PINA);

IORWPort8(DDRB);
IORWPort8(PORTB);
IORWPort8(PINB);

IORWPort8(DDRC);
IORWPort8(PORTC);
IORWPort8(PINC);

IORWPort8(DDRD);
IORWPort8(PORTD);
IORWPort8(PIND);

// RO Ports
IOROPort8(DDRA);
IOROPort8(PORTA);
IOROPort8(PINA);

IOROPort8(DDRB);
IOROPort8(PORTB);
IOROPort8(PINB);

IOROPort8(DDRC);
IOROPort8(PORTC);
IOROPort8(PINC);

IOROPort8(DDRD);
IOROPort8(PORTD);
IOROPort8(PIND);

template<class InputPort, class OutputPort, class ModePort>
struct Port
{
	using input_t = const InputPort;
	using output_t = OutputPort;
	using mode_t = ModePort;
};

// RW Ports
using ReadWritePortA = Port<ReadWritePort8PINA, ReadWritePort8PORTA, ReadWritePort8DDRA>;
using ReadWritePortB = Port<ReadWritePort8PINB, ReadWritePort8PORTB, ReadWritePort8DDRB>;
using ReadWritePortC = Port<ReadWritePort8PINC, ReadWritePort8PORTC, ReadWritePort8DDRC>;
using ReadWritePortD = Port<ReadWritePort8PIND, ReadWritePort8PORTD, ReadWritePort8DDRD>;

// RO Ports
using ReadOnlyPortA = Port<ReadOnlyPort8PINA, ReadOnlyPort8PORTA, ReadOnlyPort8DDRA>;
using ReadOnlyPortB = Port<ReadOnlyPort8PINB, ReadOnlyPort8PORTB, ReadOnlyPort8DDRB>;
using ReadOnlyPortC = Port<ReadOnlyPort8PINC, ReadOnlyPort8PORTC, ReadOnlyPort8DDRC>;
using ReadOnlyPortD = Port<ReadOnlyPort8PIND, ReadOnlyPort8PORTD, ReadOnlyPort8DDRD>;

// TODO:: Input and Output change to static polimorphic template interface
//        Undone yet!
// Input
template<typename T>
struct Input
{

	using value_type_t = typename T::value_type;

	static value_type_t bytesToRead()
	{
		return T::size();
	}
	static value_type_t read()
	{
		return T::read();
	}
	static value_type_t waitAndRead()
	{
		while (!bytesToRead())
			;
		return T::read();
	}
};

template<typename T>
struct Output
{
	using value_type_t = typename T::value_type;

	static value_type_t bytesToWrite()
	{
		return T::size();
	}

	static bool write(value_type_t value)
	{
		if (!bytesToWrite())
		{
			return false;
		}
		overwrite(value);
		return true;
	}

	static void waitAndWrite(value_type_t value)
	{
		while (!bytesToWrite())
			;
		overwrite(value);
	}

	static void overwrite(value_type_t value)
	{
		T::overwrite(value);
	}
};

} // End namespace avrcpplib

#endif // PORTS_HPP_

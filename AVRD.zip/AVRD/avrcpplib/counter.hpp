#ifndef COUNTER_HPP_
#define COUNTER_HPP_

#include <stdint.h>

namespace avrcpplib
{

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
struct Counter
{
	Counter() :
			value
			{ MinValue }
	{
	}
	explicit Counter(const ValueType& value_) :
			value
			{ value_ }
	{
	}
	ValueType& operator++();
	ValueType operator++(int);
	ValueType& operator--();
	ValueType operator--(int);
	operator ValueType() const;
private:
	ValueType value;
};

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
ValueType& Counter<ValueType, MinValue, MaxValue>::operator++()
{
	if (value == MaxValue)
	{
		value = MinValue;
	}
	else
	{
		++value;
	}
	return value;
}

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
ValueType Counter<ValueType, MinValue, MaxValue>::operator++(int)
{
	auto v = value;
	operator++();
	return v;
}

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
ValueType& Counter<ValueType, MinValue, MaxValue>::operator--()
{
	if (value == MinValue)
	{
		value = MaxValue;
	}
	else
	{
		--value;
	}
	return value;
}

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
ValueType Counter<ValueType, MinValue, MaxValue>::operator--(int)
{
	auto v = value;
	operator--();
	return v;
}

template<typename ValueType, ValueType MinValue, ValueType MaxValue>
Counter<ValueType, MinValue, MaxValue>::operator ValueType() const
{
	return value;
}

}  // namespace avrcpplib

#endif /* COUNTER_HPP_ */

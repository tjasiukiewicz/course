#ifndef PARALLEL_HPP_
#define PARALLEL_HPP_

#include <ports.hpp>
#include <util.hpp>

namespace avrcpplib
{

enum class ParallelMode
{
	PARALLEL_INPUT, PARALLEL_OUTPUT
};

// Mask and shift agregate
template<uint8_t MaskValue, uint8_t ShiftValue = countLeastZero(MaskValue)>
struct Mask
{
	constexpr static uint8_t mask = MaskValue;
	constexpr static uint8_t shift = ShiftValue;
};

template<typename Port, typename MaskAndShift>
struct ParallelPort: public IOTraits<uint8_t,
		countEnabledBits(MaskAndShift::mask)>
{

	constexpr static uint8_t mask = MaskAndShift::mask;
	constexpr static uint8_t shift = MaskAndShift::shift;
	constexpr static uint8_t min_value = 0;
	constexpr static uint8_t max_value = mask >> shift;
	using value_type = uint8_t;

	static void init(ParallelMode mode = ParallelMode::PARALLEL_OUTPUT)
	{
		auto saved_bits = (*Port::mode_t::ptr() & ~mask);
		mode == ParallelMode::PARALLEL_INPUT ?
				*Port::mode_t::ptr() = saved_bits :
				*Port::mode_t::ptr() = saved_bits | mask;
	}

	static void setPullUp()
	{
		auto saved_bits = *Port::output_t::ptr();
		*Port::output_t::ptr() = saved_bits | mask;
	}

	static value_type read()
	{
		return (*Port::input_t::ptr() & mask) >> shift;
	}

	static void write(value_type value)
	{
		auto saved_bits = *Port::output_t::ptr() & ~mask;
		value &= mask >> shift;
		*Port::output_t::ptr() = saved_bits | (value << shift);
	}

	friend ParallelPort<Port, MaskAndShift> operator<<(
			ParallelPort<Port, MaskAndShift>& port, const value_type& value)
	{
		port.write(value);
		return port;
	}

	friend ParallelPort<Port, MaskAndShift> operator>>(
			const ParallelPort<Port, MaskAndShift>& port, value_type& value)
	{
		value = port.read();
		return port;
	}
};

// Port A, B, C, D definition.
template<typename MaskAndShift>
using ParallelPortA = ParallelPort<ReadWritePortA, MaskAndShift>;

template<typename MaskAndShift>
using ParallelPortB = ParallelPort<ReadWritePortB, MaskAndShift>;

template<typename MaskAndShift>
using ParallelPortC = ParallelPort<ReadWritePortC, MaskAndShift>;

template<typename MaskAndShift>
using ParallelPortD = ParallelPort<ReadWritePortD, MaskAndShift>;

}  // namespace avrcpplib

#endif /* PARALLEL_HPP_ */

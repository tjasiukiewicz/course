#include <util/delay.h>
#include <parallel.hpp>
#include <counter.hpp>
#include <stdint.h>

using namespace avrcpplib;

constexpr static uint8_t msk1 = 0xF0;
static ParallelPortA<Mask<msk1>> par1;

int main()
{
	// Simple naive test...

	// init default output mode
	par1.init();
	Counter<uint8_t, 0, par1.max_value> counter1; // @suppress("Invalid template argument")
	for (;;)
	{
		par1 << ++counter1;
		_delay_ms(500);
	}

}
